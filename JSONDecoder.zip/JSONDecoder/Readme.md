Test api: https://news-at.zhihu.com/api/4/news/latest

​	return the latest news from @zhihu.com



Simulator environment: iPhone 8